<?php

header("Content-type: image/png");
$string = "gggg"; //$_GET['text'];
$im     = imagecreatefrompng("images/button1.png");
$orange = imagecolorallocate($im, 220, 210, 60);
$px     = (imagesx($im) - 17.5 * strlen($string)) / 2;
imagestring($im, 9, $px, 50, $string, $orange);
imagepng($im);
imagedestroy($im);

?> 