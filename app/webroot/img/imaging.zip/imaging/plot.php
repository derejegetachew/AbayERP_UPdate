<?php 

$image = @imagecreate(540, 313);

imagecolorallocate($image, 128, 128, 128);

$color = imagecolorallocate($image, 0, 0, 0);
$text_color = imagecolorallocate($image, 0, 0, 128);
// vertical axis
$x1 = 30; $y1 = 16; $x2 = 30; $y2 = 264; $t = 1;
imagefilledrectangle($image, round(min($x1, $x2) - $t), round(min($y1, $y2) - $t), round(max($x1, $x2) + $t), round(max($y1, $y2) + $t), $color);
// horizontal axis
$x1 = 26; $y1 = 260; $x2 = 534; $y2 = 260;
imagefilledrectangle($image, round(min($x1, $x2) - $t), round(min($y1, $y2) - $t), round(max($x1, $x2) + $t), round(max($y1, $y2) + $t), $color);
imageline($image, $x1 - 20, $y1 + 50, $x2, $y2 + 50, $color);

//imageline($image, $x1, $y1, $x2, $y2, $color); 
//imageline($image, 18, 260, 342, 260, $color); 

// horizontal lines
$t = 0.1;
imagestring($image, 5, 16, 252, 0, $text_color);
$w   = imagecolorallocate($image, 128, 128, 128);
$red = imagecolorallocate($image, 0, 0, 0);
$style = array($red, $red, $w, $w, $w, $w, $red, $w, $w, $w);
imagesetstyle($image, $style);
for($i = 1; $i < 12; $i++) {
	imageline($image, 32, 260 - ($i * 20), 532, 260 - ($i * 20), IMG_COLOR_STYLED );
	if($i % 2)
		imagestring($image, 5, 17 - ($i > 9? 7: 0), 252 - ($i * 20), $i, $text_color);
	if($i == 6)
		imagestring($image, 5, 1, 252 - ($i * 20), 'VA', $color);
}

imagestring($image, 5, 27, 265, 0, $text_color);
for($i = 1; $i <= 16; $i++) {
	imageline($image, 30 + ($i * 30), 256 - ($i%2?0:5), 30 + ($i * 30), 262, $color );
	$n = ($i%12==0? 12: $i%12);
	imagestring($image, 5, 27 + ($i * 30) - ($n>9?5:0), 265, $n, $text_color);
}

imageline($image, 30, 280, 30, 300, $color );
imageline($image, 30 + (12*30), 280, 30 + (12*30), 300, $color );
imagestring($image, 5, 60, 285, 'Date', $color);
imagestring($image, 5, 200, 285, '2012', $color);
imagestring($image, 5, 440, 285, '2013', $color);

$vas_od = array(28 => 10, 50 => 10, 87=>7, 68=>8, 80=>9);
$val_od = array();
foreach($vas_od as $k => $v) {
	$val_od[] = $k;
}
sort($val_od);
$color_od = imagecolorallocate($image, 98, 255, 98);
foreach($val_od as $k) {
	$v = $vas_od[$k];
	$x = 30 + $k; $y = 40 + (11 - $v) * 20; $r = 4;
	imagefilledrectangle($image, $x + $r, $y + $r, $x - $r, $y - $r, $color_od);
}

$vas_os = array(28 => 11, 50 => 10, 87=>8, 68=>10.4, 80=>9);
$color_os = imagecolorallocate($image, 255, 0, 0);
$val_os = array();
foreach($vas_os as $k => $v) {
	$val_os[] = $k;
}
sort($val_os);
foreach($val_os as $k) {
	$v = $vas_os[$k];
	$x = 30 + $k; $y = 40 + (11 - $v) * 20; $r = 6;
	imagefilledellipse($image, $x, $y, $r, $r, $color_os);
}

//print_r($val_os);

$flag_od = false;
if($vas_od[$val_od[count($val_od)-1]] < $vas_od[$val_od[count($val_od)-2]])
	$flag_od = true;

$flag_os = false;
if($vas_os[$val_os[count($val_os)-1]] < $vas_os[$val_os[count($val_os)-2]])
	$flag_os = true;

if($flag_os || $flag_od) {
	$col_poly = imagecolorallocate($image, 255, 255, 0);

	$locx = $val_od[count($val_od)-1] + 15;
	$locy = 246;
	// draw the polygon
	imagefilledpolygon($image, array ($locx + 15, $locy - 27, $locx+1, $locy, $locx + 29, $locy), 3, $col_poly);
	
	1`($image, $locx + 13, $locy - 19, $locx + 17, $locy - 12, $color_os);
	imagefilledrectangle($image, $locx + 14, $locy - 12, $locx + 16, $locy - 9,  $color_os);
	imagefilledellipse($image, $locx + 15, $locy - 4, 6, 6, $color_os);
	
	// legend
	$locx = 370;
	$locy = 15;
	// draw the polygon
	imagefilledpolygon($image, array ($locx + 8, $locy - 17, $locx, $locy, $locx + 16, $locy), 3, $col_poly);
		
	imagefilledrectangle($image, $locx + 7, $locy - 10, $locx + 9, $locy - 5, $color_os);
	//imagefilledrectangle($image, $locx + 8, $locy - 15, $locx + 16, $locy - 10, $color_os);
	imagefilledrectangle($image, $locx + 7, $locy -  3, $locx + 9, $locy - 1, $color_os);
	
	imagestring($image, 5, 390, 1, 'Visit Your Doc.', $color);
}
imagestring($image, 5, 10, 1, 'Acuity Testing Results', $color);
imagefilledrectangle($image, 230, 4, 242, 16, $color_od);
imagestring($image, 5, 250, 1, 'OD', $color);
imagefilledellipse($image, 304, 10, 10, 10, $color_os);
imagestring($image, 5, 320, 1, 'OS', $color);

// output the picture
//header("Content-type: image/png");
imagepng($image, 'graph.png');
imagedestroy($image);

?>
<img src="graph.png" />