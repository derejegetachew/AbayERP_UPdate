
<html>
<head>
<title>My Image is good</title>
</head>

<body>
<img src="button.php?text=Hi" alt="Image created by a PHP script" width="200" height="80"> 
</body>
</html>