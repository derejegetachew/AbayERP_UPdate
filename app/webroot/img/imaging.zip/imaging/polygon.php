<?php
// create a blank image
$image = imagecreatefrompng('images/grid.png');

// fill the background color
$bg = imagecolorallocate($image, 0, 0, 0);

// choose a color for the polygon
$col_poly = imagecolorallocate($image, 255, 0, 0);

// draw the rectangle
imagesetthickness($image, 4);
imagerectangle($image, 100, 100, 200, 300, $col_poly);

// output the picture
header("Content-type: image/png");
imagepng($image);

?> 